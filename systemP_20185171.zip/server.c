#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define PORTNUM 9001

int main(void)
{
	char sendMsg[256], recvMsg[256], timeMsg[256];
	struct sockaddr_in sin, cli;
	int player = 0, cnt = 0, i, line, len, typo = 0;
	double acc = 0.0f, timeSum = 0.0f, timeAvg = 0.0f;
	int sd, ns, clientlen = sizeof(cli);
	FILE *fp;

	memset((char*)&sin, '\0', sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORTNUM);
	sin.sin_addr.s_addr = inet_addr("127.0.1.1");

	if((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("socket");
		exit(1);
	}

	if(bind(sd, (struct sockaddr*)&sin, sizeof(sin)))
	{
		perror("bind");
		exit(1);
	}

	if(listen(sd, 5))
	{
		perror("listen");
		exit(1);
	}
	
	while(1)
	{
		if((ns = accept(sd, (struct sockaddr*)&cli, &clientlen)) == -1)
		{
			perror("accept");
			exit(1);
		}
		player++;
		
		switch(fork())
		{
			case 0:
				srand((unsigned int)time(NULL));
				while(1)
				{	
					fp = fopen("./textData","r");
					line = rand() % 42;
					for(i = 0; i < line; i++)
					{
						fgets(sendMsg, sizeof(sendMsg),fp);
					}
					fclose(fp);

					if(send(ns, sendMsg, sizeof(sendMsg),0) == -1)
					{
						perror("send");
						exit(1);
					}

					len = strlen(sendMsg);
					sendMsg[len-1] = '\0';
					while(1)
					{
						if((recv(ns, recvMsg, sizeof(recvMsg), 0)) == -1)
						{
							perror("read");
							exit(1);
						}

						if(!strcmp(recvMsg,"<EXIT>"))
						{
							player --;
							break;
						}
						else
						{	
							if(strcmp(sendMsg,recvMsg))
								typo++;
							else
								break;
						}
					}
					cnt++;
					
					if((recv(ns, timeMsg, sizeof(timeMsg), 0)) == -1)
					{
						perror("read");
						exit(1);
					}
					
					if(cnt == 0)
					{
						acc = 0.0f;
						timeAvg = 0.0f;
					}
					else
					{
						acc = (double)(cnt - typo) / cnt * 100;
						timeSum += atof(timeMsg);
						timeAvg = timeSum / cnt;
					}

					sprintf(recvMsg, "Accuracy : %.2lf\nTime average : %.2lf\n", acc, timeAvg);			

					if(send(ns, recvMsg, sizeof(recvMsg), 0) == -1)
					{
						perror("send");
						exit(1);
					}	
					
				}
			break;
		}
		close(ns);
	}
	close(sd);
	
	return 0;
}
