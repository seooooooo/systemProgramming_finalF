#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ncurses.h>

#define PORTNUM 9001

int main(int argc, char* argv[])
{
	time_t tt;
	int i, sd, len;
	double startTime, endTime;
	char sendMsg[256], recvMsg[256], timeAvg[256], playerName[30];
	struct sockaddr_in sin;

	memset((char*)&sin, '\0', sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORTNUM);
	sin.sin_addr.s_addr = inet_addr("127.0.1.1");

	if((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("socket");
		exit(1);
	}

	if(connect(sd, (struct sockaddr*)&sin, sizeof(sin)))
	{
		perror("connect");
		exit(1);
	}
	
	initscr();

	printw("Input your name : ");
	refresh();
	getstr(playerName);

	while(1)
	{
		if((len = recv(sd, recvMsg, sizeof(recvMsg), 0)) == -1)
		{
			perror("recv");
			exit(1);
		}
		erase();
		mvprintw(0,0, "Name : %s",playerName);
		mvprintw(10, 0, "Q : %s", recvMsg);
		refresh();
		
		len = strlen(recvMsg);
		recvMsg[len-1] = '\0';
		
		while(1)
		{
			startTime = time(&tt);
			getstr(sendMsg);
			endTime = time(&tt);


			if(send(sd, sendMsg, sizeof(sendMsg), 0) == -1)
			{
				perror("send");
				exit(1);		
			}

			if(!strcmp(sendMsg,"<EXIT>") || 
					!strcmp(sendMsg, recvMsg))
				break;

			erase();
			mvprintw(0,0, "Name : %s",playerName);
			mvprintw(10,0,"Wrong:Try Again\nQ_Again : %s\n",recvMsg);
			refresh();
		}	

		sprintf(timeAvg, "%lf", endTime-startTime);
		if(send(sd, timeAvg, sizeof(timeAvg), 0) == -1)
		{
			perror("send");
			exit(1);
		}

		if((len = recv(sd, recvMsg, sizeof(recvMsg), 0)) == -1)
		{
			perror("recv");
			exit(1);
		}

		if(!strcmp(sendMsg,"<EXIT>"))
		{
			clear();
			mvprintw(10,0,"Name : %s\n%s",playerName, recvMsg);
			refresh();
			break;
		}
		printw("Time : %.2lf\n", endTime-startTime);
		refresh();	
		sleep(1);
	}
	sleep(2);
	close(sd);
	endwin();
}
